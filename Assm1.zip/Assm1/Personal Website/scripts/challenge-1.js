/**
 * 1. Update Redux -> Node.js, React Testing Library -> MongoDB ✅
 * 2. Add new skill -> Typescript, after javascript, 2 years
 * 3. Remove "Download CV" element
 * 4. Personal image: width -> 36rem
 * 5. ✨Bonus✨ Highlight skills items: li -> click -> .underline
 */
